
  # Landing Page v01

  This is a code bundle for Landing Page v01. The original project is available at https://www.figma.com/design/9bAldVHnhl2eZZIVHhudI8/Landing-Page-v01.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  